﻿using UnityEngine;
using System.Collections.Generic;

namespace Rewired.Integration.BehaviorDesigner {

    using global::BehaviorDesigner.Runtime;
    using global::BehaviorDesigner.Runtime.Tasks;

    #region Base Classes

    public abstract class GetIntAction : Action {

        [RequiredField]
        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0;
        }

        public override TaskStatus OnUpdate() {
            return DoUpdate();
        }

        public abstract TaskStatus DoUpdate();
    }

    public abstract class GetFloatAction : Action {

        [RequiredField]
        [Tooltip("Store the result in a float variable.")]
        public SharedFloat storeValue;

        public bool everyFrame = true;

        public override void OnReset() {
            base.OnReset();
            storeValue = 0;
            everyFrame = true;
        }

        public override TaskStatus OnUpdate() {
            return DoUpdate();
        }

        public abstract TaskStatus DoUpdate();
    }

    public abstract class GetBoolAction : Action {

        [RequiredField]
        [Tooltip("Store the result in a boolean variable.")]
        public SharedBool storeValue;

        public override void OnReset() {
            base.OnReset();
            storeValue = false;
        }

        public override TaskStatus OnUpdate() {
            return DoUpdate();
        }

        public abstract TaskStatus DoUpdate();
    }

    #endregion

    #region Players

    [TaskCategory("Rewired/Global")]
    [TaskName("Get Player Count")]
    [TaskDescription("Count of Players excluding system player.")]
    [TaskIcon("Assets/Rewired/Integration/BehaviorDesigner/icon.png")]
    public class RewiredGetPlayerCount : GetIntAction {

        public override TaskStatus DoUpdate() {
            storeValue.Value = ReInput.players.playerCount;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Global")]
    [TaskName("Get All Players Count")]
    [TaskDescription("Count of all players including system player.")]
    [TaskIcon("Assets/Rewired/Integration/BehaviorDesigner/icon.png")]
    public class RewiredGetAllPlayersCount : GetIntAction {

        public override TaskStatus DoUpdate() {
            storeValue.Value = ReInput.players.allPlayerCount;
            return TaskStatus.Success;
        }
    }

    #endregion

    #region Controllers

    [TaskCategory("Rewired/Global")]
    [TaskName("Get Joystick Count")]
    [TaskDescription("The number of joysticks currently connected.")]
    [TaskIcon("Assets/Rewired/Integration/BehaviorDesigner/icon.png")]
    public class RewiredGetJoystickCount : GetIntAction {

        public override TaskStatus DoUpdate() {
            storeValue.Value = ReInput.controllers.joystickCount;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Global")]
    [TaskName("Get Custom Controller Count")]
    [TaskDescription("The number of custom controllers.")]
    [TaskIcon("Assets/Rewired/Integration/BehaviorDesigner/icon.png")]
    public class RewiredGetCustomControllerCount : GetIntAction {
        
        public override TaskStatus DoUpdate() {
            storeValue.Value = ReInput.controllers.customControllerCount;
            return TaskStatus.Success;
        }
    }

    [TaskCategory("Rewired/Global")]
    [TaskName("Get Last Active Controller Type")]
    [TaskDescription("Get the last controller type that produced input.")]
    [TaskIcon("Assets/Rewired/Integration/BehaviorDesigner/icon.png")]
    public class RewiredGetLastActiveControllerType : GetIntAction {

        public override TaskStatus DoUpdate() {
            storeValue.Value = (int)ReInput.controllers.GetLastActiveControllerType();
            return TaskStatus.Success;
        }
    }

    #endregion

    #region Time

    [TaskCategory("Rewired/Global")]
    [TaskName("Get Unscaled Time")]
    [TaskDescription("Current unscaled time since start of the game. Always use this when doing current time comparisons for button and axis active/inactive times instead of Time.time or Time.unscaledTime.")]
    [TaskIcon("Assets/Rewired/Integration/BehaviorDesigner/icon.png")]
    public class RewiredGetUnscaledTime : GetFloatAction {

        public override TaskStatus DoUpdate() {
            storeValue.Value = ReInput.time.unscaledTime;
            return TaskStatus.Success;
        }
    }

    #endregion

    #region Events

    [TaskCategory("Rewired/Events")]
    [TaskName("Controller Connected Event")]
    [TaskDescription("Event triggered when a controller is conected.")]
    [TaskIcon("Assets/Rewired/Integration/BehaviorDesigner/icon.png")]
    public class RewiredControllerConnectedEvent : Conditional {

        [Tooltip("Store the result in a string variable.")]
        public SharedString storeControllerName;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerId = -1;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerType = 0;

        private bool hasEvent = false;

        public override void OnAwake() {
            base.OnAwake();
            ReInput.ControllerConnectedEvent += OnControllerConnected;
        }

        public override void OnReset() {
            base.OnReset();
            storeControllerName = string.Empty;
            storeControllerId = -1;
            storeControllerType = 0;
            hasEvent = false;
        }

        public override void OnBehaviorComplete() {
            ReInput.ControllerDisconnectedEvent -= OnControllerConnected;
        }

        public override TaskStatus OnUpdate() {
            
            return DoUpdate();
        }

        public TaskStatus DoUpdate() {
            if(!hasEvent) return TaskStatus.Failure;
            hasEvent = false;
            return TaskStatus.Success;
        }

        private void OnControllerConnected(ControllerStatusChangedEventArgs args) {
            hasEvent = true;
            storeControllerName.Value = args.name;
            storeControllerId.Value = args.controllerId;
            storeControllerType.Value = (int)args.controllerType;
        }
    }

    [TaskCategory("Rewired/Events")]
    [TaskName("Controller Disconnected Event")]
    [TaskDescription("Event triggered after a controller is disconnected.")]
    [TaskIcon("Assets/Rewired/Integration/BehaviorDesigner/icon.png")]
    public class RewiredControllerDisconnectedEvent : Conditional {

        [Tooltip("Store the result in a string variable.")]
        public SharedString storeControllerName;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerId = -1;

        [Tooltip("Store the result in an int variable.")]
        public SharedInt storeControllerType = 0;

        private bool hasEvent = false;

        public override void OnAwake() {
            base.OnAwake();
            ReInput.ControllerDisconnectedEvent += OnControllerDisconnected;
        }

        public override void OnReset() {
            base.OnReset();
            storeControllerName = string.Empty;
            storeControllerId = -1;
            storeControllerType = 0;
            hasEvent = false;
        }

        public override void OnBehaviorComplete() {
            ReInput.ControllerDisconnectedEvent -= OnControllerDisconnected;
        }

        public override TaskStatus OnUpdate() {
            return DoUpdate();
        }

        public TaskStatus DoUpdate() {
            if(!hasEvent) return TaskStatus.Failure;
            hasEvent = false;
            return TaskStatus.Success;
        }

        private void OnControllerDisconnected(ControllerStatusChangedEventArgs args) {
            hasEvent = true;
            storeControllerName.Value = args.name;
            storeControllerId.Value = args.controllerId;
            storeControllerType.Value = (int)args.controllerType;
        }
    }

    #endregion
}
